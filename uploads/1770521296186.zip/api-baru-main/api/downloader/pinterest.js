const express = require('express');
const fetch = require('node-fetch');
const router = express.Router();

async function pinterest(url) {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)" },
      redirect: "follow"
    })
    const data = await res.text()
    const video = data.match(/"contentUrl":"(https:\/\/v1\.pinimg\.com\/videos\/[^"]+\.mp4)"/)
    const image =
      data.match(/"imageSpec_736x":\{"url":"(https:\/\/i\.pinimg\.com\/736x\/[^"]+)"/) ||
      data.match(/"imageSpec_564x":\{"url":"(https:\/\/i\.pinimg\.com\/564x\/[^"]+)"/)
    const title = data.match(/"name":"([^"]+)"/)
    const author = data.match(/"fullName":"([^"]+)".+?"username":"([^"]+)"/)
    return {
      type: video ? "video" : "image",
      title: title?.[1] || "-",
      author: author?.[1] || "-",
      username: author?.[2] || "-",
      media: video?.[1] || image?.[1] || "-",
    }
  } catch (e) {
    return { error: e.message }
  }
}

router.get('/', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: "Missing 'url' parameter" });
  try {
    const anu = await pinterest(url);
    return res.json(anu);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;
