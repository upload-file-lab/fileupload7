const express = require('express');
const axios = require('axios');
const router = express.Router();

async function getTokenFBDOWN() {
  const url = "https://fbdownloader.to/id";
  const { data: html } = await axios.get(url, {
    headers: {
      "User-Agent": "Mozilla/5.0",
      "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"
    }
  });
  const regex = /k_exp="(.*?)".*?k_token="(.*?)"/s;
  const match = html.match(regex);
  if (!match) throw new Error("token g ada");
  return {
    k_exp: match[1],
    k_token: match[2]
  };
}
async function fbDownloader(fbUrl) {
  const { k_exp, k_token } = await getTokenFBDOWN();
  const payload = new URLSearchParams({
    k_exp,
    k_token,
    p: "home",
    q: fbUrl,
    lang: "id",
    v: "v2",
    W: ""
  });
  const { data } = await axios.post("https://fbdownloader.to/api/ajaxSearch", payload, {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "User-Agent": "Mozilla/5.0",
      "X-Requested-With": "XMLHttpRequest",
      "Origin": "https://fbdownloader.to",
      "Referer": "https://fbdownloader.to/id"
    }
  });
  if (!data || !data.data) throw new Error("gagal");
  const html = data.data;
  const results = [];
  const rowRegex = /<td class="video-quality">(.*?)<\/td>[\s\S]*?(?:href="(.*?)"|data-videourl="(.*?)")/g;
  let match;
  while ((match = rowRegex.exec(html)) !== null) {
    const quality = match[1].trim();
    const url = match[2] || match[3];
    if (quality && url) results.push({ quality, url });
  }
  return results;
}

router.get('/', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: "Missing 'url' parameter" });
  try {
    const y = await fbDownloader(url);
    const video720p = y.find(item => item.quality.includes("720p"));
    const video360p = y.find(item => item.quality.includes("360p"));
    const video540p = y.find(item => item.quality.includes("540p"));
    const url720p = video720p?.url || "Tidak tersedia";
    const url360p = video360p?.url || "Tidak tersedia";
    const url540p = video540p?.url || "Tidak tersedia";
    const succesy = 'succes';
    const data = {
      status: succesy,
      video: {
        360: url360p,
        540: url540p,
        720: url720p
      }
    };
    return res.json(data);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;