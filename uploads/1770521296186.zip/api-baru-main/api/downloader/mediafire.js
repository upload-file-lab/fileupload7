const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const { lookup } = require("mime-types");
const router = express.Router();
async function mediafire(url) {
    try {  
        const response = await axios.get(url);
        const html = response.data;

        const $ = cheerio.load(html);
        
        const fileName = $('.dl-btn-label').attr('title')
        const fileSize = $('.details li:contains("File size") span').text().trim()
        const extension = fileName.split('.').pop()
        const mimeType = lookup(extension.toLowerCase())
        const uploadDate = $('.details li:contains("Uploaded") span').text().trim()
        const downloadUrl = $('.download_link a.input').attr('href')
        
        return {
            fileName,
            fileSize,
            mimeType,
            uploadDate,
            downloadUrl
        }
        
    } catch (error) {
        console.error('Error fetching data:', error.message);
        return null;
    }
}
router.get('/', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: "Missing 'url' parameter" });
  try {
    const anu = await mediafire(url);
    return res.json(anu);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;
