const express = require('express');
const axios = require('axios');
const crypto = require('crypto');
const router = express.Router();

router.get('/', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: "Missing 'url' parameter" });
  try {
    const data = await ytdl(`${url}`,"mp3",`128`);
    return res.json(data);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;

async function ytdl(url, type = 'mp4', quality = '720') {
  try {
    if (!/^https?:\/\//i.test(url)) throw new Error('Invalid URL.');
    
    const id = [
      /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
      /youtu\.be\/([a-zA-Z0-9_-]{11})/
    ].find(p => p.test(url))?.[Symbol.match](url)?.[1];
    
    if (!id) throw new Error('Failed to extract link.');

    const apiFormat = type === 'mp3' ? 'mp3' : quality;
  
    const api = axios.create({
      headers: {
        'content-type': 'application/json',
        'origin': 'https://yt.savetube.me',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });
    
    const { data: { cdn } } = await api.get('https://media.savetube.vip/api/random-cdn');
    const { data: { data: encryptedData } } = await api.post(`https://${cdn}/v2/info`, {
      url: `https://www.youtube.com/watch?v=${id}`
    });
    
    const encrypted = Buffer.from(encryptedData, 'base64');
    const decipher = crypto.createDecipheriv('aes-128-cbc', Buffer.from('C5D58EF67A7584E4A29F6C35BBC4EB12', 'hex'), encrypted.slice(0, 16));
    const decrypted = JSON.parse(Buffer.concat([decipher.update(encrypted.slice(16)), decipher.final()]).toString());
    
    const { data: { data: { downloadUrl } } } = await api.post(`https://${cdn}/download`, {
      id,
      downloadType: type === 'mp3' ? 'audio' : 'video',
      quality: type === 'mp3' ? '128' : quality,
      key: decrypted.key
    });
  
    return {
      id,
      title: decrypted.title || null,
      format: type,
      quality: type === 'mp3' ? '128kbps' : quality + 'p',
      duration: `${Math.floor(decrypted.duration / 60).toString().padStart(2, '0')}:${(decrypted.duration % 60).toString().padStart(2, '0')}`,
      thumbnail: `https://i.ytimg.com/vi/${id}/maxresdefault.jpg`,
      downloadUrl: downloadUrl
    };
  } catch (error) {
    throw new Error(error.message);
  }
}
