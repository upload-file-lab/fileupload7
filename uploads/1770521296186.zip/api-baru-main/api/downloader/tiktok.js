const express = require('express');
const fetch = require('node-fetch');
const router = express.Router();

router.get('/', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: "Missing 'url' parameter" });
  try {
    const anu = await fetch('https://ttdl.iyayn.web.id/api/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    }).then(r => r.json());
    return res.json(anu);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;