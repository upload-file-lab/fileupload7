const express = require('express');
const axios = require('axios');
const router = express.Router();

router.get('/', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: "Missing 'url' parameter" });
  try {
    const data = await ytdl(`${url}`,"mp3",`128k`);
    return res.json(data);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;


const CONFIG = {
  audio: { ext: ["mp3", "m4a", "wav", "opus", "flac"], q: ["best", "320k", "128k"] },
  video: { ext: ["mp4"], q: ["144p", "240p", "360p", "480p", "720p", "1080p"] }
};

const headers = {
  accept: "application/json", "content-type": "application/json",
  "user-agent": "Mozilla/5.0 (Android)", referer: "https://ytmp3.gg/"
};

const poll = async (url) => {
  const { data } = await axios.get(url, { headers });
  if (data.status === "completed") return data;
  if (data.status === "failed") throw "Convert gagal";
  await new Promise(r => setTimeout(r, 1500));
  return poll(url);
};

async function ytdl(url, format = "mp3", quality = "128k") {
  const type = Object.keys(CONFIG).find(k => CONFIG[k].ext.includes(format));
  if (!type) throw "Format tidak didukung";
  if (!CONFIG[type].q.includes(quality)) throw `Kualitas untuk ${type} tidak valid`;
  
  const videoId = url.match(/(?:v=|\/)([0-9A-Za-z_-]{11})/)?.[1];
  const { data: meta } = await axios.get("https://www.youtube.com/oembed", { params: { url, format: "json" } });
  
  const payload = {
    url, os: "android",
    output: { type, format, ...(type === "video" && { quality }) },
    ...(type === "audio" && { audio: { bitrate: quality } })
  };
  
  const req = u => axios.post(`https://${u}.ytconvert.org/api/download`, payload, { headers });
  const { data } = await req("hub").catch(() => req("api"));

  const result = await poll(data.statusUrl);

  return {
    id: videoId,
    title: meta.title,
    format: format,
    quality: quality.includes('k') ? quality + 'bps' : quality,
    duration: result.duration,
    thumbnail: `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`,
    downloadUrl: result.downloadUrl
  };
}
