const express = require('express');
const fetch = require('node-fetch');
const axios = require('axios')
const FormData = require('form-data')
const router = express.Router();

router.get('/', async (req, res) => {
  const imgurl = req.query.imgurl;
  if (!imgurl) return res.status(400).json({ error: "Missing 'imgurl' parameter" });
  try {
    const bufferyeah = await fetch(imgurl).then((response) => response.buffer());
    const buffernya = await removebg(bufferyeah);
    res.writeHead(200, {
      'Content-Type': 'image/png',
      'Content-Length': buffernya.length,
    });
    return res.end(buffernya);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;

async function removebg(buffer) {
  try {
    const html = await axios.get('https://www.iloveimg.com/remove-background')

    const token = html.data.match(/"token":"([^"]+)"/)?.[1]
    const task = html.data.match(/taskId\s*=\s*'([^']+)'/)?.[1]

    if (!token || !task) throw new Error('Token atau task tidak ditemukan')

    const up = new FormData()
    up.append('name', 'image.jpg')
    up.append('chunk', '0')
    up.append('chunks', '1')
    up.append('task', task)
    up.append('preview', '1')
    up.append('pdfinfo', '0')
    up.append('pdfforms', '0')
    up.append('pdfresetforms', '0')
    up.append('v', 'web.0')
    up.append('file', buffer, {
      filename: 'image.jpg',
      contentType: 'image/jpeg'
    })

    const upload = await axios.post(
      'https://api5g.iloveimg.com/v1/upload',
      up,
      {
        headers: {
          ...up.getHeaders(),
          Authorization: `Bearer ${token}`,
          origin: 'https://www.iloveimg.com',
          referer: 'https://www.iloveimg.com/'
        }
      }
    )

    const proses = await axios.post(
      'https://api5g.iloveimg.com/v1/removebackground',
      new URLSearchParams({
        task,
        server_filename: upload.data.server_filename
      }).toString(),
      {
        responseType: 'arraybuffer',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          origin: 'https://www.iloveimg.com',
          referer: 'https://www.iloveimg.com/'
        }
      }
    )

    return Buffer.from(proses.data)
  } catch (e) {
    throw e
  }
}
