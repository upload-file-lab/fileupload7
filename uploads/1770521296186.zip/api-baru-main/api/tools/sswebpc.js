const express = require('express');
const fetch = require('node-fetch')
const router = express.Router();
const sswebpc = {
    _static: Object.freeze({
        baseUrl: 'https://www.screenshotmachine.com',
        baseHeaders: {
            'content-encoding': 'zstd'
        },
        taskName: 'ssweb',
        displayLog: true,
        maxOutputLength: 200
    }),

    log: function (message) {
        if (this._static.displayLog) {
            console.log(`[${this._static.taskName}] ${message}`)
        }
    },

    pretyError: function (string) {
        if (!string) return '(empty message)'
        let message = ''
        try {
            message = JSON.stringify(string, null, 2)
        } catch (_) {
            message = string
        }
        if (message.length >= this._static.maxOutputLength) {
            message = message.substring(0, this._static.maxOutputLength) + ' [trimmed]'
        }
        return message
    },

    getCookie: async function () {
        this.log('coba ambil kuki')
        try {
            const r = await fetch(this._static.baseUrl, {
                headers: this._static.baseHeaders
            })
            
            if (!r.ok) {
                throw Error(`${r.status} ${r.statusText} at getCookie function. ${this.pretyError(await r.text())}`)
            }

            // Debug: cek semua headers yang tersedia
            const headersList = [...r.headers.keys()]
            this.log(`Available headers: ${headersList.join(', ')}`)

            let cookies = [];
            
            // Cek beberapa cara untuk mendapatkan cookie
            if (r.headers.get('set-cookie')) {
                // Untuk fetch standar atau node-fetch v3
                const setCookieHeader = r.headers.get('set-cookie')
                cookies = Array.isArray(setCookieHeader) ? setCookieHeader : [setCookieHeader]
                this.log(`Got cookies via get('set-cookie'): ${cookies.length} cookies found`)
            } 
            else if (r.headers.raw && typeof r.headers.raw === 'function') {
                // Untuk node-fetch v2
                const rawHeaders = r.headers.raw()
                if (rawHeaders['set-cookie']) {
                    cookies = rawHeaders['set-cookie']
                    this.log(`Got cookies via headers.raw(): ${cookies.length} cookies found`)
                }
            }
            else if (r.headers.getAll && typeof r.headers.getAll === 'function') {
                // Metode alternatif
                try {
                    cookies = r.headers.getAll('set-cookie')
                    this.log(`Got cookies via getAll(): ${cookies.length} cookies found`)
                } catch (e) {
                    this.log(`getAll() failed: ${e.message}`)
                }
            }

            if (cookies.length === 0) {
                // Coba iterasi semua headers untuk mencari cookie
                for (const [key, value] of r.headers.entries()) {
                    if (key.toLowerCase() === 'set-cookie') {
                        cookies.push(value)
                    }
                }
                if (cookies.length > 0) {
                    this.log(`Found cookies via iteration: ${cookies.length} cookies`)
                }
            }

            if (cookies.length === 0) {
                throw Error('Tidak bisa menemukan cookie di response headers')
            }

            // Proses cookies
            const cookieString = cookies
                .map(kuki => {
                    // Ambil bagian sebelum ';' untuk setiap cookie
                    const parts = kuki.split(';')
                    return parts[0].trim()
                })
                .filter(cookie => cookie) // Hilangkan yang kosong
                .join('; ')

            if (!cookieString) {
                throw Error('Gagal memproses cookie (cookie string kosong setelah diproses)')
            }

            this.log(`Cookie berhasil didapat: ${cookieString.substring(0, 50)}${cookieString.length > 50 ? '...' : ''}`)
            return { cookie: cookieString }

        } catch (error) {
            this.log(`Error di getCookie: ${error.message}`)
            throw error
        }
    },

    getBuffer: async function (reqObj, cookie) {
        this.log('coba download buffer')
        if (reqObj.status !== "success") {
            throw Error(`Status tidak sukses: ${reqObj.status || 'unknown'}`)
        }
        
        const { link } = reqObj
        if (!link) {
            throw Error('Tidak ada link di response object')
        }
        
        const api = this._static.baseUrl + '/' + link
        this.log(`Download dari: ${api}`)
        
        const r = await fetch(api, {
            headers: {
                cookie: cookie,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        })
        
        if (!r.ok) {
            throw Error(`${r.status} ${r.statusText} at getBuffer function. ${this.pretyError(await r.text())}`)
        }
        
        const contentType = r.headers.get('content-type')
        this.log(`Content-Type: ${contentType}`)
        
        const ab = await r.arrayBuffer()
        const buffer = Buffer.from(ab)
        
        this.log(`Buffer size: ${buffer.length} bytes`)
        return { buffer }
    },

    req: async function (url, cookie) {
        this.log('mencoba hit server.. agak lama emang disini')
        const headers = {
            cookie: cookie,
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            ...this._static.baseHeaders
        }
        
        const path = '/capture.php'
        const encodedUrl = encodeURIComponent(url)
        const body = "url=" + encodedUrl + "&device=desktop&cacheLimit=0"
        
        this.log(`Request ke: ${this._static.baseUrl + path}`)
        this.log(`URL target: ${url}`)
        
        const r = await fetch(this._static.baseUrl + path, {
            headers,
            body: body,
            method: "POST"
        });
        
        if (!r.ok) {
            throw Error(`${r.status} ${r.statusText} at req function. ${this.pretyError(await r.text())}`)
        }
        
        const textResponse = await r.text()
        this.log(`Response raw: ${textResponse.substring(0, 100)}...`)
        
        let reqObj;
        try {
            reqObj = JSON.parse(textResponse)
        } catch (e) {
            throw Error(`Gagal parse JSON response: ${e.message}. Response: ${textResponse.substring(0, 200)}`)
        }
        
        this.log(`Response status: ${reqObj.status || 'unknown'}`)
        return { reqObj }
    },

    capture: async function (url) {
        try {
            if (!url) throw Error('param url gak boleh kosong')
            
            this.log(`Memulai capture untuk: ${url}`)
            
            // Ambil cookie
            const { cookie } = await this.getCookie()
            if (!cookie) {
                throw Error('Cookie kosong')
            }
            
            // Request screenshot
            const { reqObj } = await this.req(url, cookie)
            
            // Cek status response
            if (!reqObj || reqObj.status !== "success") {
                const errorMsg = reqObj ? JSON.stringify(reqObj) : 'Response objek kosong'
                throw Error(`Server mengembalikan status tidak sukses: ${errorMsg}`)
            }
            
            if (!reqObj.link) {
                throw Error('Tidak ada link screenshot di response')
            }
            
            // Download buffer
            const { buffer } = await this.getBuffer(reqObj, cookie)
            
            if (!buffer || buffer.length === 0) {
                throw Error('Buffer kosong atau tidak valid')
            }
            
            this.log('Semua task berhasil!')
            this.log(`Ukuran gambar: ${buffer.length} bytes`)
            
            return buffer
            
        } catch (error) {
            this.log(`Error di capture: ${error.message}`)
            this.log(`Stack trace: ${error.stack}`)
            throw error
        }
    }
}

router.get('/', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: "Missing 'url' parameter" });
  try {
    const buffernya = await sswebpc.capture(url);
    res.writeHead(200, {
      'Content-Type': 'image/png',
      'Content-Length': buffernya.length,
    });
    return res.end(buffernya);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;
