const express = require('express');
const fetch = require('node-fetch');
const CryptoJS = require('crypto-js');
const axios = require('axios');
const router = express.Router();

const aeskey = 'ai-enhancer-web__aes-key';
const aesiv = 'aienhancer-aesiv';

const headers = {
  'Content-Type': 'application/json',
  'Origin': 'https://aienhancer.ai',
  'Referer': 'https://aienhancer.ai/ai-image-editor',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
};

function encrypt(obj) {
  return CryptoJS.AES.encrypt(
    JSON.stringify(obj),
    CryptoJS.enc.Utf8.parse(aeskey),
    {
      iv: CryptoJS.enc.Utf8.parse(aesiv),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    }
  ).toString();
}

async function imageditor(image, prompt) {
  const settings = encrypt({
    prompt,
    size: '2K',
    aspect_ratio: 'match_input_image',
    output_format: 'jpeg',
    max_images: 1
  });

  const create = await axios.post('https://aienhancer.ai/api/v1/k/image-enhance/create',
    {
      model: 2,
      image,
      function: 'ai-image-editor',
      settings
    },
    { headers }
  );

  const id = create.data.data.id;

  for (;;) {
    await new Promise(r => setTimeout(r, 2500));

    const res = await axios.post('https://aienhancer.ai/api/v1/k/image-enhance/result',
      { task_id: id },
      { headers }
    );

    const data = res.data.data;

    if (data.status === 'success') {
      return {
        id,
        output: data.output,
        input: data.input
      };
    }
    
    if (data.status === 'failed') {
      throw new Error("AI Processing failed");
    }
  }
}

router.get('/', async (req, res) => {
  const text = req.query.text;
  const imgurl = req.query.imgurl;

  if (!text || !imgurl) return res.status(400).json({ error: "Missing 'text' or 'imgurl' parameter" });

  try {
    const response = await fetch(imgurl);
    const bufferyeah = await response.buffer();
    const base64Image = `data:image/jpeg;base64,${bufferyeah.toString('base64')}`;

    const edit = await imageditor(base64Image, text);

    const finalResponse = await fetch(edit.output);
    const buffer = await finalResponse.buffer();

    res.writeHead(200, {
      'Content-Type': 'image/png',
      'Content-Length': buffer.length,
    });
    res.end(buffer);

  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});

module.exports = router;
