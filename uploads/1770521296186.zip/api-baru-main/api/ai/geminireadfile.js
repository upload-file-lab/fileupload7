const express = require('express');
const { GoogleGenAI } = require("@google/genai");
const fetch = require('node-fetch');
const { fromBuffer } = require('file-type');
const router = express.Router();

router.get('/', async (req, res) => {
  const text = req.query.text;
  const fileurl = req.query.fileurl;
  const apikey = req.query.apikey;
  if (!text || !fileurl || !apikey) return res.status(400).json({ error: "Missing 'text', 'fileurl' or 'apikey' parameter" });
  try {
    const ai = new GoogleGenAI({ apiKey: `${apikey}` });
    const mediaBuffer = await fetch(fileurl).then((response) => response.buffer());
    const hehe = await fromBuffer(mediaBuffer);
    const base64ImageFile = Buffer.from(mediaBuffer).toString("base64");
    const contents = [
      {
        inlineData: {
          mimeType: hehe.mime,
          data: base64ImageFile,
        },
      },
      { text: text },
    ];
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: contents,
    });
    const data = {
      text: response.text
    };
    return res.json(data);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;