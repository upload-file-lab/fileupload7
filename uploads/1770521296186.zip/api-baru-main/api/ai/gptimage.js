const express = require('express');
const fetch = require('node-fetch');
const axios = require('axios');
const router = express.Router();

router.get('/', async (req, res) => {
  const text = req.query.text;
  const imgurl = req.query.imgurl;
  if (!text || !imgurl) return res.status(400).json({ error: "Missing 'text' or 'imgurl' parameter" });
  try {
    const bufferyeah = await fetch(imgurl).then((response) => response.buffer());
    const buffer = await gptimage(text, bufferyeah);
    res.writeHead(200, {
      'Content-Type': 'image/png',
      'Content-Length': buffer.length,
    });
    res.end(buffer);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});

module.exports = router;

async function gptimage(prompt, buffer) {
    try {
        if (!prompt) throw new Error('Prompt is required.');
        if (!Buffer.isBuffer(buffer)) throw new Error('Image must be a buffer.');
        
        const { data } = await axios.post(
            'https://ghibli-proxy.netlify.app/.netlify/functions/ghibli-proxy',
            {
                image: 'data:image/png;base64,' + buffer.toString('base64'),
                prompt,
                model: 'gpt-image-1',
                n: 1,
                size: 'auto',
                quality: 'low'
            },
            {
                headers: {
                    origin: 'https://overchat.ai',
                    referer: 'https://overchat.ai/',
                    'user-agent': 'Mozilla/5.0'
                }
            }
        );

        const result = data?.data?.[0]?.b64_json;
        if (!result) throw new Error('No result found.');

        return Buffer.from(result, 'base64');
    } catch (error) {
        throw new Error(error.message);
    }
}
