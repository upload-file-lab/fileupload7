const express = require('express');
const fetch = require('node-fetch');
const axios = require('axios');
const router = express.Router();

router.get('/', async (req, res) => {
  const text = req.query.text;
  if (!text) return res.status(400).json({ error: "Missing 'text' parameter" });
  try {
    let imageUrl = await deepimg(text);
    const buffer = await fetch(imageUrl).then((response) => response.buffer());
    res.writeHead(200, {
      'Content-Type': 'image/png',
      'Content-Length': buffer.length,
    });
    res.end(buffer);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;

async function deepimg(prompt) {
  try {
    let { data } = await axios.post("https://api-preview.chatgot.io/api/v1/deepimg/flux-1-dev", {
      prompt,
      size: "1024x1024",
      device_id: `dev-${Math.floor(Math.random() * 1000000)}`
    }, {
      headers: {
        "Content-Type": "application/json",
        Origin: "https://deepimg.ai",
        Referer: "https://deepimg.ai/"
      }
    })
    return data?.data?.images?.[0]?.url || null
  } catch (err) {
    console.error(err.response ? err.response.data : err.message)
    return null
  }
}
