const express = require('express');
const fetch = require('node-fetch');
const router = express.Router();

router.get('/', async (req, res) => {
  const text = req.query.text;
  if (!text) return res.status(400).json({ error: "Missing 'text' parameter" });
  try {
    const buffernya = await fetch(`https://skyzxu-brat.hf.space/brat?text=${text}`).then((response) => response.buffer());
    res.writeHead(200, {
      'Content-Type': 'image/png',
      'Content-Length': buffernya.length,
    });
    return res.end(buffernya);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;