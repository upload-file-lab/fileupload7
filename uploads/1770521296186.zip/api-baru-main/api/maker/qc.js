const express = require('express');
const axios = require('axios');
const router = express.Router();

router.get('/', async (req, res) => {
  const text = req.query.text;
  const name = req.query.name;
  const color = req.query.color;
  const imgurl = req.query.imgurl;
  if (!text || !name || !color || !imgurl) return res.status(400).json({ error: "Missing 'text', 'name', 'color', or 'imgurl' parameter" });
  try {
    const buffernya = await qc(text, name, color, imgurl);
    res.writeHead(200, {
      'Content-Type': 'image/png',
      'Content-Length': buffernya.length,
    });
    return res.end(buffernya);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});
module.exports = router;

async function qc(text, name, color, linkimage) {
    const colors = {
        'pink': '#f68ac9', 'blue': '#6cace4', 'red': '#f44336', 'green': '#4caf50',
        'yellow': '#ffeb3b', 'purple': '#9c27b0', 'darkblue': '#0d47a1', 'lightblue': '#03a9f4',
        'ash': '#9e9e9e', 'orange': '#ff9800', 'black': '#000000', 'white': '#ffffff',
        'teal': '#008080', 'lightpink': '#FFC0CB', 'chocolate': '#A52A2A', 'salmon': '#FFA07A',
        'magenta': '#FF00FF', 'tan': '#D2B48C', 'wheat': '#F5DEB3', 'deeppink': '#FF1493',
        'fire': '#B22222', 'skyblue': '#00BFFF', 'brightskyblue': '#1E90FF', 'hotpink': '#FF69B4',
        'lightskyblue': '#87CEEB', 'seagreen': '#20B2AA', 'darkred': '#8B0000', 'orangered': '#FF4500',
        'cyan': '#48D1CC', 'violet': '#BA55D3', 'mossgreen': '#00FF7F', 'darkgreen': '#008000',
        'navyblue': '#191970', 'darkorange': '#FF8C00', 'darkpurple': '#9400D3', 'fuchsia': '#FF00FF',
        'darkmagenta': '#8B008B', 'darkgray': '#2F4F4F', 'peachpuff': '#FFDAB9', 'blackishgreen': '#BDB76B',
        'darkishred': '#DC143C', 'goldenrod': '#DAA520', 'darkishgray': '#696969', 'darkishpurple': '#483D8B',
        'gold': '#FFD700', 'silver': '#C0C0C0'
    };

    const backgroundColor = colors[color.toLowerCase()] || color || '#ffffff';

    const obj = {
        type: 'quote',
        format: 'png',
        backgroundColor,
        width: 512,
        height: 768,
        scale: 2,
        messages: [{
            entities: [],
            avatar: true,
            from: {
                id: 1,
                name: name,
                photo: { url: linkimage }
            },
            text: text,
            replyMessage: {}
        }]
    };

    try {
        const response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
            headers: { 'Content-Type': 'application/json' }
        });
        return Buffer.from(response.data.result.image, 'base64');
    } catch (e) {
        throw e;
    }
}


